document.getElementById('pdf-file').addEventListener('change', function() {
    const fileName = this.files[0].name;
    this.nextElementSibling.innerText = fileName;
});
