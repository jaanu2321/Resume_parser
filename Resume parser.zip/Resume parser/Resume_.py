from pdfminer.high_level import extract_text
from get_yml import get_yml
 
def extract_text_from_pdf(pdf_path):
    return extract_text(pdf_path)
 
 
path = r"D:\res.pdf"

if __name__ == '__main__':
    data = extract_text_from_pdf(path)
    data = data.replace(" ","").replace("\n","").lower()
    # print (f"{type(data)}\n\n{data}")  # noqa: T001 my   

    
    list2 = []
    ymldata=get_yml()
    tot=len(ymldata["list1"])

    # print(ymldata["list1"],type(ymldata["list1"]))

    for skill in ymldata["list1"]:
        if skill in data:
            list2.append(skill)

    print(list2)
    print((len(list2)/tot)*100 )



#python -m venv {environment_name}

#{environment_name}\Scripts\activate