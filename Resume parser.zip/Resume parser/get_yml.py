
import yaml
def get_yml():
    with open('skills.yml', 'r') as f:
        data = yaml.load(f, Loader=yaml.SafeLoader)
#    # Print the values as a dictionary
    return data



